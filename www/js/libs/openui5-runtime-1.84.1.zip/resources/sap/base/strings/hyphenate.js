/*!
 * OpenUI5
 * (c) Copyright 2009-2020 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var r=/([A-Z])/g;var h=function(s){return s.replace(r,function(m,c){return"-"+c.toLowerCase();});};return h;});
