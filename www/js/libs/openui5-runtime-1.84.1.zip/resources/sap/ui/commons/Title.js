/*!
 * OpenUI5
 * (c) Copyright 2009-2020 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['./library','sap/ui/core/Title'],function(l,C){"use strict";var T=C.extend("sap.ui.commons.Title",{metadata:{deprecated:true,library:"sap.ui.commons"}});return T;});
