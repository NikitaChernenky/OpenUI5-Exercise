/*!
 * OpenUI5
 * (c) Copyright 2009-2020 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['./MenuItemBase','./library','sap/ui/unified/Menu','./MenuRenderer'],function(M,l,U,a){"use strict";var b=U.extend("sap.ui.commons.Menu",{metadata:{deprecated:true,library:"sap.ui.commons"}});b.prototype.bCozySupported=false;return b;});
